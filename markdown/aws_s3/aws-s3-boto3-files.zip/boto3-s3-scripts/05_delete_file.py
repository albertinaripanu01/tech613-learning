import boto3

bucket_name = "tech613-albertina-test-boto3"
object_name = "boto3-test.txt"

s3 = boto3.client("s3")
s3.delete_object(Bucket=bucket_name, Key=object_name)

print(f"Deleted {object_name} from {bucket_name}")
