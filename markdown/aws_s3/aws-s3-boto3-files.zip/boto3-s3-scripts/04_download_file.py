import boto3

bucket_name = "tech613-albertina-test-boto3"
object_name = "boto3-test.txt"
download_name = "downloaded-boto3-test.txt"

s3 = boto3.client("s3")
s3.download_file(bucket_name, object_name, download_name)

print(f"Downloaded {object_name} as {download_name}")
