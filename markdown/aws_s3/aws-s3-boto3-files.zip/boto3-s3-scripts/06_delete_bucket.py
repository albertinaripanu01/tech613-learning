import boto3

bucket_name = "tech613-albertina-test-boto3"
s3 = boto3.client("s3")
s3.delete_bucket(Bucket=bucket_name)

print(f"Deleted bucket: {bucket_name}")
