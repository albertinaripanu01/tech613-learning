import boto3

bucket_name = "tech613-albertina-test-boto3"
file_name = "boto3-test.txt"

with open(file_name, "w") as file:
    file.write("This file was uploaded to S3 with Python boto3.\n")

s3 = boto3.client("s3")
s3.upload_file(file_name, bucket_name, file_name)

print(f"Uploaded {file_name} to {bucket_name}")
