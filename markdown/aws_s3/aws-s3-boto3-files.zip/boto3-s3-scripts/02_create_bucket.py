import boto3

bucket_name = "tech613-albertina-test-boto3"
s3 = boto3.client("s3", region_name="eu-west-1")

s3.create_bucket(
    Bucket=bucket_name,
    CreateBucketConfiguration={"LocationConstraint": "eu-west-1"},
)

print(f"Created bucket: {bucket_name}")
