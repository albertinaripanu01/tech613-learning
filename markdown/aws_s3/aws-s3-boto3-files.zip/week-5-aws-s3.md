# Week 5: Launch an EC2 Instance and Use Amazon S3

## 1. Launch the EC2 instance

In the AWS Console, launch a new EC2 instance with the following settings:

| Setting | Value |
| --- | --- |
| Instance name | `tech613-albertina-learn-s3` |
| AMI | Ubuntu Server 22.04 LTS |
| Instance type | `t3.micro` |
| Key pair | `albertina` |
| Security group | Select existing security group: `tech613-ramon-allow-ssh-http` |

Select **Launch instance**, then open the newly created instance.

## 2. Connect and update the server

Connect to the instance through Git Bash, then update Ubuntu:

```bash
sudo apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get upgrade -y
```

## 3. Set up the AWS CLI

Install the AWS CLI if it is not already installed, then confirm the installed version:

```bash
aws --version
```

Configure the CLI and enter your AWS access credentials when prompted:

```bash
aws configure
```

Use the following configuration values:

| Prompt | Value |
| --- | --- |
| Default region name | `eu-west-1` |
| Default output format | `json` |

## 4. Work with Amazon S3

List the S3 buckets available to your AWS account:

```bash
aws s3 ls
```

View help for S3 commands:

```bash
aws s3 help
```

Create an S3 bucket:

```bash
aws s3 mb s3://tech515-ramon-first-bucket
```

Create a local test file:

```bash
echo This is the first line in a test file > test.txt
```

Upload the file to the S3 bucket:

```bash
aws s3 cp test.txt s3://tech515-ramon-first-bucket
```

List the objects stored in the bucket:

```bash
aws s3 ls s3://tech515-ramon-first-bucket
```

> The final command lists files (objects) in the specified bucket. Use `aws s3 ls` without a bucket name to list all buckets.

## 5. Additional S3 commands

| Task | Command |
| --- | --- |
| List buckets | `aws s3 ls` |
| Create a bucket | `aws s3 mb s3://tech515-ramon-first-bucket` |
| Upload a file | `aws s3 cp test.txt s3://tech515-ramon-first-bucket` |
| List files in a bucket | `aws s3 ls s3://tech515-ramon-first-bucket` |
| Download all bucket files to the current folder | `aws s3 sync s3://tech515-ramon-first-bucket .` |
| Download one file | `aws s3 cp s3://tech515-ramon-first-bucket/test.txt .` |

Remove every file in the bucket:

```bash
aws s3 rm s3://tech515-ramon-first-bucket --recursive
```

> **Danger:** This deletes all files in the bucket without prompting.

Remove the bucket and all files it contains:

```bash
aws s3 rb s3://tech515-ramon-first-bucket --force
```

> **Danger:** This deletes the bucket and every file in it without prompting.

## 6. Manage Amazon S3 with Python Boto3

An existing running EC2 instance is available in `eu-west-1`, so it can be used for this task. If a new instance is needed, create an Ubuntu 22.04 `t3.micro` instance named `tech613-albertina-s3-boto3-task`.

### Install the required dependencies

Connect to the EC2 instance with Git Bash, then install the AWS CLI, Python, pip, and Boto3:

```bash
sudo apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get upgrade -y
sudo apt-get install -y python3 python3-pip awscli
python3 -m pip install --user boto3
```

Confirm the installation:

```bash
aws --version
python3 --version
python3 -m pip show boto3
```

### Authenticate the AWS CLI and Boto3

Run the following command and enter the IAM access key and secret access key when prompted:

```bash
aws configure
```

Set the default region to `eu-west-1` and the default output format to `json`. The AWS CLI stores credentials in `~/.aws/credentials`, and Boto3 automatically reads that file.

Verify the authenticated identity:

```bash
aws sts get-caller-identity
```

### Run the Boto3 scripts

Copy the scripts to the EC2 instance and run them in sequence. They use the bucket name `tech613-albertina-test-boto3`; S3 bucket names must be globally unique, so change the name in every script if AWS reports that it is already taken.

| Step | Script | Purpose | Run command |
| --- | --- | --- | --- |
| 1 | `01_list_buckets.py` | List all S3 buckets. | `python3 01_list_buckets.py` |
| 2 | `02_create_bucket.py` | Create the test bucket in `eu-west-1`. | `python3 02_create_bucket.py` |
| 3 | `03_upload_file.py` | Create and upload `boto3-test.txt`. | `python3 03_upload_file.py` |
| 4 | `04_download_file.py` | Download the file as `downloaded-boto3-test.txt`. | `python3 04_download_file.py` |
| 5 | `05_delete_file.py` | Delete `boto3-test.txt` from S3. | `python3 05_delete_file.py` |
| 6 | `06_delete_bucket.py` | Delete the empty test bucket. | `python3 06_delete_bucket.py` |

Each script has one focused Boto3 operation and deliberately omits detailed error handling, as required.

### AWS references

- [Boto3: create_bucket](https://docs.aws.amazon.com/boto3/latest/reference/services/s3/client/create_bucket.html)
- [Boto3: upload_file](https://docs.aws.amazon.com/boto3/latest/reference/services/s3/client/upload_file.html)
- [Boto3: download_file](https://docs.aws.amazon.com/boto3/latest/reference/services/s3/client/download_file.html)
- [Boto3: delete_bucket](https://docs.aws.amazon.com/boto3/latest/reference/services/s3/client/delete_bucket.html)
